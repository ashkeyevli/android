package com.example.calculator1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private CalculatorModel calculator;
    private TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] numberids=new int[]{
                R.id.btn_zero,
                R.id.btn_one,
                R.id.btn_two,
                R.id.btn_three,
                R.id.btn_four,
                R.id.btn_five,
                R.id.btn_six,
                R.id.btn_seven,
                R.id.btn_eight,
                R.id.btn_nine

        };
        int[] actionsids=new int[]{
                R.id.btn_plus,
                R.id.btn_minus,
                R.id.btn_mult,
                R.id.btn_divide,
                R.id.btn_del,
                R.id.btn_c,
                R.id.btn_percent,
                R.id.btn_root,
                R.id.btn_equal,

                R.id.btn_dot

        };
        text=findViewById(R.id.text);
        text.setMovementMethod(new ScrollingMovementMethod());
        calculator=new CalculatorModel();

        View.OnClickListener numberButtonClickListener  = new View.OnClickListener() {
        @Override
        public void onClick(View view){
            calculator.onNumPressed(view.getId());
            text.setText(calculator.getText());

        }
        };

        View.OnClickListener actionButtonOneClickListener= new View.OnClickListener(){
            @Override
        public void onClick(View view) {
            calculator.onActionPressed(view.getId());
                text.setText(calculator.getText());
            }
        };
        for(int i=0;i<numberids.length;i++){
            findViewById(numberids[i]).setOnClickListener(numberButtonClickListener);
        }
        for(int i=0;i<actionsids.length;i++){
            findViewById(actionsids[i]).setOnClickListener(actionButtonOneClickListener);
        }

    }
}
