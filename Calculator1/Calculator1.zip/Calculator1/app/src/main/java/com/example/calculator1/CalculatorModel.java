package com.example.calculator1;

public class CalculatorModel {
    int firstArg;
    int secondArg;

    StringBuilder inputStr=new StringBuilder();
    private int actionSelected;
    private State state;
    private enum State{
        firstArgInput,
        secondArgInput,
        resultShow
    }
    public CalculatorModel(){
        state=State.firstArgInput;

    }
    public void onNumPressed(int buttonId){
        if(state==State.resultShow){
            state=State.firstArgInput;
            inputStr.setLength(0);
        }



        if(inputStr.length()<32){
        switch (buttonId){
            case R.id.btn_zero:
                if(inputStr.length()!=0){
                    inputStr.append("0");
                    break;
                }
            case R.id.btn_one:
                inputStr.append("1");
                break;
            case R.id.btn_two:
                inputStr.append("2");
                break;
            case R.id.btn_three:
                inputStr.append("3");
                break;
            case R.id.btn_four:
                inputStr.append("4");
                break;
            case R.id.btn_five:
                inputStr.append("5");
                break;
            case R.id.btn_six:
                inputStr.append("6");
                break;
            case R.id.btn_seven:
                inputStr.append("7");
                break;
            case R.id.btn_eight:
                inputStr.append("8");
                break;
            case R.id.btn_nine:
                inputStr.append("9");
                break;
        }
        }
    }

    public void onActionPressed(int actionId) {
        if(actionId==R.id.btn_c){
            actionSelected=R.id.btn_c;
            inputStr.setLength(0);
            inputStr.append("");}
        if (actionId == R.id.btn_equal&& state==State.secondArgInput) {
            secondArg=Integer.parseInt(inputStr.toString());
            state=State.resultShow;
            inputStr.setLength(0);
            switch (actionSelected){

                case R.id.btn_plus:
                    actionSelected = R.id.btn_plus;
                    inputStr.append(firstArg+secondArg);
                    break;

                case R.id.btn_minus:
                    actionSelected = R.id.btn_minus;
                    inputStr.append(firstArg-secondArg);
                    break;
                case R.id.btn_mult:
                    actionSelected = R.id.btn_mult;
                    inputStr.append(firstArg*secondArg);
                    break;
                case R.id.btn_divide:
                    actionSelected = R.id.btn_divide;
                    inputStr.append(firstArg/secondArg);
                    break;
                case R.id.btn_root:
                    actionSelected = R.id.btn_root;
                    break;
                case R.id.btn_percent:
                    actionSelected = R.id.btn_percent;

                    break;


                case R.id.btn_del:
                    actionSelected = R.id.btn_del;
                    break;
                case R.id.btn_equal:
                    actionSelected = R.id.btn_equal;
                    break;

            }

        }
        else if (inputStr.length() > 0&&state==State.firstArgInput) {
            firstArg=Integer.parseInt(inputStr.toString());
            state=State.secondArgInput;
            inputStr.setLength(0);
            switch (actionId) {
                case R.id.btn_plus:
                    actionSelected = R.id.btn_plus;
                    break;

                case R.id.btn_minus:
                    actionSelected = R.id.btn_minus;
                    break;
                case R.id.btn_mult:
                    actionSelected = R.id.btn_mult;
                    break;
                case R.id.btn_divide:
                    actionSelected = R.id.btn_divide;
                    break;
                case R.id.btn_root:
                    actionSelected = R.id.btn_root;
                    break;
                case R.id.btn_percent:
                    actionSelected = R.id.btn_percent;
                    inputStr.append(firstArg/100);
                    break;


                case R.id.btn_del:
                    actionSelected = R.id.btn_del;
                    break;
                case R.id.btn_equal:
                    actionSelected = R.id.btn_equal;
                    break;
            }
        }
    }

    public String getText(){
        return inputStr.toString();
    }
}
